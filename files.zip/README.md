# Strategieboost Website

Statische website voor **Strategieboost** — Nuchter denken, doordacht doen.

## Bestanden

| Bestand | Beschrijving |
|---|---|
| `index.html` | Hoofdpagina van de Strategieboost website |
| `Strategiescan.html` | Strategiescan tool / landingspagina |

## Gebruik

Open `index.html` in je browser, of host de bestanden op een statische webhost zoals:

- [GitHub Pages](https://pages.github.com/) (gratis, direct vanuit deze repo)
- [Netlify](https://netlify.com/)
- [Vercel](https://vercel.com/)

## GitHub Pages activeren

1. Ga naar **Settings → Pages**
2. Kies bij *Source*: `Deploy from a branch`
3. Selecteer branch `main`, map `/ (root)`
4. Klik **Save** — je site is live op `https://[jouw-gebruikersnaam].github.io/strategieboost/`

---

*Gemaakt met ❤️ door Strategieboost*
